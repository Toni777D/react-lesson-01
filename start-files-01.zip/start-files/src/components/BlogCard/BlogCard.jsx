export const BlogCard = () => {
  return <h2>BlogCard</h2>;
};
