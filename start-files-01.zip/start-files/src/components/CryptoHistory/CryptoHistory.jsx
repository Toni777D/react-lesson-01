// const tableHeaders = ['№', 'price', 'amount', 'date'];

export const CryptoHistory = () => {
  return <h2>CryptoHistory</h2>;
};
