export const StatisticsItem = () => {
  return <h3>StatisticsItem</h3>;
};
