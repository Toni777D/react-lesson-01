// import { FaRegThumbsUp } from 'react-icons/fa';
// import { MdPeople, MdOutlineProductionQuantityLimits } from 'react-icons/md';
// import { GiTreeDoor } from 'react-icons/gi';
// import { StatisticsItem } from '../StatisticsItem/StatisticsItem';
// import style from './Statistics.module.css';

export const Statistics = () => {
  return <h2>Statistics</h2>;
};
